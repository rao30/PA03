//
// Created by Richie on 2/27/2019.
//
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
int checkFile(FILE *fp);

